# 个人投资者的信息集 · 第二轮 TeX 工程

最终稿为 44 页正文和 6 页备份。解压后在本目录运行 `pwsh -File build.ps1`，等待两遍 XeLaTeX 全部结束；PDF 输出到 `build/main.pdf`。

需要 TeX Live 的 XeLaTeX、Beamer、xeCJK、TikZ、colortbl 和 Latin Modern。中文优先 KaiTi/FangSong，缺失时使用 Fandol。全部输入和图件均在包内，不依赖旧工程。主题上游文件与许可保留，本地无水印设置在 ruc-research.sty。

- [完整口述稿](约30分钟口述讲稿.md)和[30 分钟预算](讲述与计时.md)
- 六块内容设计在 `manuscript/`；正文依次为 part-1、part-2、part-3、part-4a、part-4b、part-5.tex。
- [语义校订](review/第二轮微调_01_语义校订与执行规范.md)、[逐页清单](review/第二轮微调_02_逐页调整清单.md)、[核查记录](review/第二轮微调_03_核查记录.md)及原始转写在 review。
- [截图来源及裁切坐标](assets/yahoo-snapshot-source.md)。图中当代行情只作教学实例，PCA 输入三行也是构造例。

`项目README.md` 是仓库版入口的原件，其外部相对链接按仓库结构解释；本包请从当前 README 开始。`源码文件清单.json` 记录归档文件 SHA256。包不含临时编译文件；实际投影与真人计时仍需排练。
